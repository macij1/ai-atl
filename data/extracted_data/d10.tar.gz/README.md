# pydata-recognition

https://www.overleaf.com/project/61952e169bc13e853ee07173
