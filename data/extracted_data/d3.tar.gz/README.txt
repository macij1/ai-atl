* Contents

Makefile	Makefile for compling coling 2020.tex in pdflatex
README.txt	This file
colig.bst		BibTeX `coling' style file
coling2020.dotx	Microsoft Word template file for Coling 2020
coling2020.pdf	PDF file for Coling 2020
coling2020.sty	LaTeX style file for Coling 2020
coling2020.tex	LaTeX sample file for Coling 2020
coling2020.bib	LaTeX bib file for Coling 2020
