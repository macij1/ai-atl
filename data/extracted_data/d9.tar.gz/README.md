# README

Whenever you make a change in this repo, please submit a pull request. We are using a branch protection rule that prevents you from pushing directly into `main`.

For instructions on the paper writing process, please refer to [this Workplace post](https://fb.workplace.com/groups/283103424414981/posts/432486686143320).
