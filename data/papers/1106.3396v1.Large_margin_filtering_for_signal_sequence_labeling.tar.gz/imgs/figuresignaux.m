%% génération 
n=50;
d=5;

X=rand(n,d);
tfilt=3;

filt=ones(tfilt,1)/tfilt;

Xf=filter(filt,1,X);

sig=Xf(tfilt:end,:)+repmat((1:d),n-tfilt+1,1)-0.5;

%%

figure(1)

nbkeep=20;

plot(sig(1:nbkeep,:),'*-')

set(gca,'Ytick',[1:d])