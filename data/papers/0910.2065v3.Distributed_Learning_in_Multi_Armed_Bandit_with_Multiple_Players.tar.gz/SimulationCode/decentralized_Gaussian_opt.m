close all;
clear all;
mu=1:1:10;
MC=20;
T=5000;
M=4;
for N=9:9
NL=1:N;
delta=1/(N+1);
Ereward=zeros(M,T);
reward=zeros(M,T);
for o=1:MC
    m=zeros(1,M);
    md=zeros(M,2^N);
    mean=zeros(M,N);
    playtime=zeros(M,N);
    for t=1:T
        k=mod(t,M);
        if(k==0)
                k=M;
        end
        m(k)=m(k)+1;
        x=randn(1,N)+mu(1:N);
           for i=1:M
               if (i==k)
                   if (m(i)<=N)
                       a(i,t)=m(i);
                   else
                       index=find(playtime(i,:)>=delta*(m(i)-1));
                       [temp,leader_index]=max(mean(i,index));
                       leader=index(leader_index);
                       j=mod(m(i),N);
                       if(j==0)
                          j=N;
                       end
                       if(mean(i,j)+(2*log(t-1)/playtime(i,j))^(1/2)>=mean(i,leader))
                            a(i,t)=j;
                       else
                           a(i,t)=leader;
                       end
                   end
               else
                   if (m(k)<=N)
                       a(i,t)=m(k);
                   else
                       if(k>i)
                           dc=a(i,t-k+i:t-1);
                       else
                           dc=a(i,t-k+i-M:t-1);
                       end
                        dc=sort(dc);
                        ldc=length(dc);
                        bdc=zeros(1,N);
                        bdc(dc)=1;
                        sdc=0;
                        for w=1:N
                        sdc=bdc(w)*2^(N-w)+sdc;
                        end
                        md(i,sdc)=md(i,sdc)+1;
                        remain=NL;
                       for v=1:ldc
                        remain_index=find(remain~=dc(v));
                        remain=remain(remain_index);
                       end
                       index=find(playtime(i,remain)>=delta*(md(i,sdc)-1));
                       [temp,leader_index]=max(mean(i,remain(index)));
                       leader=remain(index(leader_index));
                       j=mod(md(i,sdc),N-ldc);
                       if(j==0)
                          j=N-ldc;
                       end
                       j=remain(j);
                       if(mean(i,j)+(2*log(t-1)/playtime(i,j))^(1/2)>=mean(i,leader))
                            a(i,t)=j;
                       else
                           a(i,t)=leader;
                       end
                   end
               end
               mean(i,a(i,t))=(mean(i,a(i,t))*playtime(i,a(i,t))+x(a(i,t)))/(playtime(i,a(i,t))+1);
               playtime(i,a(i,t))=playtime(i,a(i,t))+1;
           end 
           for b=1:N
               index_r=find(a(:,t)==b);
               if (length(index_r)>=1)
                   reward(index_r(1),t)=reward(index_r(1),t)+x(a(index_r(1),t));
               end
           end         
    end
end
Ereward=reward/MC;
regret(N,:)=sum(mu([N-M+1:N]))-sum(Ereward,1);
end

% T=1000
% plot(T,n_expect(M,T)./log(T))