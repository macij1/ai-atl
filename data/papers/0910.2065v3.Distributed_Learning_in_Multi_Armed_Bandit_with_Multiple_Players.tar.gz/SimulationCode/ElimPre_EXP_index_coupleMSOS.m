close all;
clear all;
mu=1:1:10;
MC=100;
T=5000;
N=10;
NL=1:N;
delta=1/(N+1);
for M=6:9;
Ereward=zeros(M,T);
reward=zeros(M,T);
arrival_time=randi(100,1,M)
for mt=1:MC
    m=zeros(M,M,M);
    mean=zeros(M,N);
    playtime=zeros(M,N);    
    md=zeros(M,2^N,M);
%     mean_s=zeros(M,N,2^N,M);
%     playtime_s=zeros(M,N,2^N,M);
    Offset=zeros(M,T);
    Offset_count=zeros(M,M);
    a=zeros(M,T);
    Collision_ind=zeros(M,T);
    x=zeros(M,N);
    for t=1:T
        for i=1:M
        x(i,:)=rand(1,N);
        x(i,:)=-log(1-x(i,:)).*mu(1:N);
        end
           for i=1:M
               if(arrival_time(i)<=t)
             o=Offset(i,t)+1;
             Offset_count(i,o)=Offset_count(i,o)+1;
                    if(sum(Offset_count(i,:))<=N)
                       a(i,t)=sum(Offset_count(i,:));
                       m(i,1,o)=m(i,1,o)+1;
                       md(i,:,o)=md(i,:,o)+1;
                       else
                               target_arm=mod(Offset_count(i,o)-o+1,M);
                               if(target_arm==0)
                                    target_arm=M;
                               end
                               m(i,target_arm,o)=m(i,target_arm,o)+1;
                               sample_mean=mean(i,:)./playtime(i,:);
                        if(target_arm==1)
                       UCB=sample_mean+20*min((2*(log(sum(Offset_count(i,:))-1)+...
                           2*log(log(sum(Offset_count(i,:))-1)))./playtime(i,:)).^(1/2),1);
                       [temp,a(i,t)]=max(UCB);
                                else
                                 index_offset=find(Offset(i,(arrival_time(i):t))==o-1);
                                 if(length(index_offset)<=target_arm-1)
                                     index_offset=[(1:1+target_arm-1-length(index_offset)),...
                                         index_offset]; 
                                 end
                                 dc=a(i,index_offset(length(index_offset)-target_arm+1:length(index_offset)-1)+arrival_time(i)-1);
                                 dc=sort(dc);
                                 ldc=length(dc);
                                 bdc=zeros(1,N);
                                 bdc(dc)=1;
                                 sdc=0;
                                 for w=1:N
                                 sdc=bdc(w)*2^(N-w)+sdc;
                                 end
                                md(i,sdc,o)=md(i,sdc,o)+1;
                                remain=NL;
                               for v=1:ldc
                               remain_index=find(remain~=dc(v));
                               remain=remain(remain_index);
                               end
                        sample_mean=mean(i,remain)./playtime(i,remain);
                        %UCB=sample_mean+(2*(log(md(i,sdc))+2*log(log(md(i,sdc))))./playtime_s(i,remain,sdc)).^(1/2);
                        UCB=sample_mean+20*min((2*(log(sum(Offset_count(i,:))-1)+2*log(log(sum(Offset_count(i,:)))))./playtime(i,remain)).^(1/2),1);
                        [temp,a(i,t)]=max(UCB);
                        a(i,t)=remain(a(i,t));
                       end
                    end
                        playtime(i,a(i,t))=playtime(i,a(i,t))+1;
                       mean(i,a(i,t))=mean(i,a(i,t))+x(i,a(i,t));
               end
           end         
                   
           for b=1:N
               index_r=find(a(:,t)==b);
               if (length(index_r)==1)
                   reward(index_r,t)=reward(index_r,t)+x(index_r,a(index_r,t));
               else
                   if(length(index_r)>1)
                       Collision_ind(index_r,t)=1;
                   end
               end
           end
           for i=1:M
                       if(t>=M&&mod(sum(Offset_count(i,:)),M)==0&&sum(Collision_ind(i,(t-M+1:t)))>0)
                       Offset(i,t+1)=randi(M,1)-1;
                       else
                         Offset(i,t+1)= Offset(i,t);
                       end
          end
    end         
end
Ereward=reward/MC;
regret(M,:)=sum(mu([N-M+1:N]))-sum(Ereward,1);
end

% T=1000
% plot(T,n_expect(M,T)./log(T))