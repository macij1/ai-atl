close all;
clear all;
mu=1:1:10;
MC=100;
T=5000;
M=2;
for N=3:10
NL=1:N;
delta=1/(N+1);
Ereward=zeros(M,T);
reward=zeros(M,T);
for o=1:MC
    m=zeros(1,M);
    md=zeros(M,2^N);
    mean=zeros(M,N);
    playtime=zeros(M,N);
    x=zeros(M,N);
    for t=1:T
        k=mod(t,M);
        if(k==0)
                k=M;
        end
        m(k)=m(k)+1;
        for i=1:M
        x(i,:)=rand(1,N);
        x(i,:)=-log(1-x(i,:)).*mu(1:N);
        end
           for i=1:M
               if (i==k)
                   if (m(i)<=N)
                       a(i,t)=m(i);
                   else
                       UCB=mean(i,:)+20*min((2*(log(t-1)+2*log(log(t)))./playtime(i,:)).^(1/2),1);
                       [temp,a(i,t)]=max(UCB);
                   end
               else
                   if (m(k)<=N)
                       a(i,t)=m(k);
                   else
                       if(k>i)
                           dc=a(i,t-k+i:t-1);
                       else
                           dc=a(i,t-k+i-M:t-1);
                       end
                        dc=sort(dc);
                        ldc=length(dc);
                        bdc=zeros(1,N);
                        bdc(dc)=1;
                        sdc=0;
                        for w=1:N
                        sdc=bdc(w)*2^(N-w)+sdc;
                        end
                        md(i,sdc)=md(i,sdc)+1;
                        remain=NL;
                       for v=1:ldc
                        remain_index=find(remain~=dc(v));
                        remain=remain(remain_index);
                       end
                       UCB=mean(i,remain)+20*min((2*(log(t-1)+2*log(log(t)))./playtime(i,:)).^(1/2),1);
                       [temp,a(i,t)]=max(UCB);
                       a(i,t)=remain(a(i,t));
                   end
               end
               mean(i,a(i,t))=(mean(i,a(i,t))*playtime(i,a(i,t))+x(i,a(i,t)))/(playtime(i,a(i,t))+1);
               playtime(i,a(i,t))=playtime(i,a(i,t))+1;
           end 
           for b=1:N
               index_r=find(a(:,t)==b);
               if (length(index_r)==1)
                   reward(index_r(1),t)=reward(index_r(1),t)+x(index_r(1),a(index_r(1),t));
               end
           end         
    end
end
Ereward=reward/MC;
regret(N,:)=sum(mu([N-M+1:N]))-sum(Ereward,1);
end

% T=1000
% plot(T,n_expect(M,T)./log(T))