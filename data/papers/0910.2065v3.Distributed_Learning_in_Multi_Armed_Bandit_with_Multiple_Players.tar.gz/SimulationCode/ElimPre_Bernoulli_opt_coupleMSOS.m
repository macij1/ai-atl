close all;
clear all;
mu=.1:.1:.9;
MC=100;
T=5000;
N=9;
NL=1:N;
delta=1/(N+1);
for M=5:5;
Ereward=zeros(M,T);
reward=zeros(M,T);
arrival_time=ones(1,M)
for mt=1:MC
    m=zeros(M,M,M);
    mean=zeros(M,N);
    playtime=zeros(M,N);    
    md=zeros(M,2^N,M);
%     mean_s=zeros(M,N,2^N,M);
%     playtime_s=zeros(M,N,2^N,M);
    Offset=zeros(M,T);
    Offset_count=zeros(M,M);
    a=zeros(M,T);
    Collision_ind=zeros(M,T);
    for t=1:T
        x=(rand(1,N)<mu(1:N));
           for i=1:M
               if(arrival_time(i)<=t)
             o=Offset(i,t)+1;
             Offset_count(i,o)=Offset_count(i,o)+1;
                    if(sum(Offset_count(i,:))<=N)
                       a(i,t)=sum(Offset_count(i,:));
                       m(i,1,o)=m(i,1,o)+1;
                       md(i,:,o)=md(i,:,o)+1;
                       else
                               target_arm=mod(Offset_count(i,o)-o+1,M);
                               if(target_arm==0)
                                    target_arm=M;
                               end
                               m(i,target_arm,o)=m(i,target_arm,o)+1;
                               sample_mean=mean(i,:)./playtime(i,:);
                        if(target_arm==1)
                                    index=find(playtime(i,:)>=delta*(t-arrival_time(i)));
                                    [temp,leader_index]=max(sample_mean(index));
                                    leader=index(leader_index);
                                    j=mod(m(i,target_arm,o),N);
                                   if(j==0)
                                    j=N;
                                   end
                                 if(sample_mean(leader)<=sample_mean(j)||sample_mean(j)==0)
                                   a(i,t)=j;
                                 else
                                   if(sample_mean(leader)==1)
                                        a(i,t)=leader;
                                   else
                                     if(sample_mean(j)*log(sample_mean(j)/sample_mean(leader))+...
                                   (1-sample_mean(j))*log((1-sample_mean(j))/(1-sample_mean(leader)))...
                                   <=log(sum(Offset_count(i,:))-1)/playtime(i,j))
                                      a(i,t)=j;
                                     else
                                      a(i,t)=leader;
                                     end
                                   end 
                                 end
                                else
                                 index_offset=find(Offset(i,(arrival_time(i):t))==o-1);
                                 if(length(index_offset)<=target_arm-1)
                                     index_offset=[(1:1+target_arm-1-length(index_offset)),...
                                         index_offset]; 
                                 end
                                 dc=a(i,index_offset(length(index_offset)-target_arm+1:length(index_offset)-1)+arrival_time(i)-1);
                                 dc=sort(dc);
                                 ldc=length(dc);
                                 bdc=zeros(1,N);
                                 bdc(dc)=1;
                                 sdc=0;
                                 for w=1:N
                                 sdc=bdc(w)*2^(N-w)+sdc;
                                 end
                                md(i,sdc,o)=md(i,sdc,o)+1;
                                remain=NL;
                               for v=1:ldc
                               remain_index=find(remain~=dc(v));
                               remain=remain(remain_index);
                               end
                              index=find(playtime(i,remain)>=delta*(sum(md(i,sdc,:))-1));
                               [temp,leader_index]=max(sample_mean(remain(index)));
                               leader=remain(index(leader_index));
                               j=mod(md(i,sdc,o),N-ldc);
                               if(j==0)
                                  j=N-ldc;
                               end
                               j=remain(j);
                               if(sample_mean(leader)<=sample_mean(j)||sample_mean(j)==0)
                                    a(i,t)=j;
                               else
                                    if(sample_mean(leader)==1)
                                        a(i,t)=leader;
                                    else
                                       if(sample_mean(j)*log(sample_mean(j)/sample_mean(leader))+...
                                         (1-sample_mean(j))*log((1-sample_mean(j))/(1-sample_mean(leader)))...
                                           <=log(sum(Offset_count(i,:))-1)/playtime(i,j))
                                          a(i,t)=j;
                                       else
                                          a(i,t)=leader;
                                       end
                                    end 
                               end
                       end
                    end
                        playtime(i,a(i,t))=playtime(i,a(i,t))+1;
                       mean(i,a(i,t))=mean(i,a(i,t))+x(a(i,t));
               end
           end         
                   
           for b=1:N
               index_r=find(a(:,t)==b);
               if (length(index_r)==1)
                   reward(index_r,t)=reward(index_r,t)+x(a(index_r,t));
               else
                   if(length(index_r)>1&&x(b)==1)
                       Collision_ind(index_r,t)=1;
                   end
               end
           end
           for i=1:M
                       if(t>=M&&mod(sum(Offset_count(i,:)),M)==0&&sum(Collision_ind(i,(t-M+1:t)))>0)
                       Offset(i,t+1)=randi(M,1)-1;
                       else
                         Offset(i,t+1)= Offset(i,t);
                       end
          end
    end         
end
Ereward=reward/MC;
regret(M,:)=sum(mu([N-M+1:N]))-sum(Ereward,1);
end

% T=1000
% plot(T,n_expect(M,T)./log(T))