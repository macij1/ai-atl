close all;
clear all;
mu=0.1:0.1:0.9;
%mu=0.05:0.05:0.95;
MC=100;
T=5000;
M=2;
for N=9:9;
NL=1:N;
delta=1/(N+1);
Ereward=zeros(M,T);
reward=zeros(M,T);
% Ereward_p=zeros(M,T);
% reward_p=zeros(M,T);
% Ereward_r=zeros(M,T);
% reward_r=zeros(M,T);
for o=1:MC
    m=zeros(1,M);
    md=zeros(M,2^N);
    mean=zeros(M,N);
    playtime=zeros(M,N);
%     mean_p=zeros(M,N);
%     playtime_p=zeros(M,N);
%     mean_r=zeros(M,N);
%     playtime_r=zeros(M,N);
    z=zeros(M,T);
    for t=1:T
        k=mod(t,M);
        if(k==0)
                k=M;
        end
        m(k)=m(k)+1;
        x=(rand(1,N)<mu(1:N));
           for i=1:M
               if (i==k)
                   if (m(i)<=N)
                       a(i,t)=m(i);
                   else
                       index=find(playtime(i,:)>=delta*(m(i)-1));
                       [temp,leader_index]=max(mean(i,index));
                       leader=index(leader_index);
                       j=mod(m(i),N);
                       if(j==0)
                          j=N;
                       end
                       if(mean(i,leader)<=mean(i,j)||mean(i,j)==0)
                            a(i,t)=j;
                       else
                           if(mean(i,leader)==1)
                               a(i,t)=leader;
                           else
                               if(mean(i,j)*log(mean(i,j)/mean(i,leader))+(1-mean(i,j))*log((1-mean(i,j))/(1-mean(i,leader)))...
                                  <=log(t-1)/playtime(i,j))
                                   a(i,t)=j;
                               else
                                   a(i,t)=leader;
                               end
                           end 
                       end
                   end
               else
                   if (m(k)<=N)
                       a(i,t)=m(k);
                   else
                       if(k>i)
                           dc=a(i,t-k+i:t-1);
                       else
                           dc=a(i,t-k+i-M:t-1);
                       end
                        dc=sort(dc);
                        ldc=length(dc);
                        bdc=zeros(1,N);
                        bdc(dc)=1;
                        sdc=0;
                        for w=1:N
                        sdc=bdc(w)*2^(N-w)+sdc;
                        end
                        md(i,sdc)=md(i,sdc)+1;
                        remain=NL;
                       for v=1:ldc
                        remain_index=find(remain~=dc(v));
                        remain=remain(remain_index);
                       end
                       index=find(playtime(i,remain)>=delta*(md(i,sdc)-1));
                       [temp,leader_index]=max(mean(i,remain(index)));
                       leader=remain(index(leader_index));
                       j=mod(md(i,sdc),N-ldc);
                       if(j==0)
                          j=N-ldc;
                       end
                       j=remain(j);
                       if(mean(i,leader)<=mean(i,j)||mean(i,j)==0)
                            a(i,t)=j;
                       else
                           if(mean(i,leader)==1)
                               a(i,t)=leader;
                           else
                               if(mean(i,j)*log(mean(i,j)/mean(i,leader))+(1-mean(i,j))*log((1-mean(i,j))/(1-mean(i,leader)))...
                                  <=log(t-1)/playtime(i,j))
                                   a(i,t)=j;
                               else
                                   a(i,t)=leader;
                               end
                           end 
                       end
                   end
               end
               mean(i,a(i,t))=(mean(i,a(i,t))*playtime(i,a(i,t))+x(a(i,t)))/(playtime(i,a(i,t))+1);
               playtime(i,a(i,t))=playtime(i,a(i,t))+1;
%                if(t<=N)
%                    a_p(i,t)=t;
%                else
%                    [temp,index_p]=sort(mean_p(i,:)+sqrt(2*log(t-1)./playtime_p(i,:)),'descend');
%                    a_p(i,t)=index_p(i);
%                end
%                mean_p(i,a_p(i,t))=(mean_p(i,a_p(i,t))*playtime_p(i,a_p(i,t))+x(a_p(i,t)))/(playtime_p(i,a_p(i,t))+1);
%                playtime_p(i,a_p(i,t))=playtime_p(i,a_p(i,t))+1;
%                if(t<=N)
%                    a_r(i,t)=t;
%                    u(i)=1;
%                else
%                    [temp,index_rr]=sort(mean_r(i,:)+sqrt(2*log(t-1)./playtime_r(i,:)),'descend');
%                    if(z(i,t-1)==0)
%                        u(i)=ceil(rand(1)*M);
%                    end
%                    a_r(i,t)=index_rr(u(i));
%                end
%                mean_r(i,a_r(i,t))=(mean_r(i,a_r(i,t))*playtime_r(i,a_r(i,t))+x(a_r(i,t)))/(playtime_r(i,a_r(i,t))+1);
%                playtime_r(i,a_r(i,t))=playtime_r(i,a_r(i,t))+1;
           end 
           for b=1:N
               index_r=find(a(:,t)==b);
               if (length(index_r)==1)
                   reward(index_r(1),t)=reward(index_r(1),t)+x(a(index_r(1),t));
               end
%                index_r_p=find(a_p(:,t)==b);
%                if (length(index_r_p)==1)
%                    reward_p(index_r_p,t)=reward_p(index_r_p,t)+x(a_p(index_r_p,t));
%                end
%                index_r_r=find(a_r(:,t)==b);
%                if (length(index_r_r)==1)
%                    reward_r(index_r_r,t)=reward_r(index_r_r,t)+x(a_r(index_r_r,t));
%                    z(a_r(index_r_r,t),t)=x(a_r(index_r_r,t));
%                end
           end 
    end
%     count(o,:)=playtime(1,:);
end
Ereward=reward/MC;
regret(N,:)=sum(mu([N-M+1:N]))-sum(Ereward,1);
% Ereward_p=sum(reward_p,2)/MC;
% regret_p(M)=T*sum(mu([N-M+1:N]))-sum(Ereward_p);
% Ereward_r=sum(reward_r,2)/MC;
% regret_r(M)=T*sum(mu([N-M+1:N]))-sum(Ereward_r);
end

% T=1000
% plot(T,n_expect(M,T)./log(T))